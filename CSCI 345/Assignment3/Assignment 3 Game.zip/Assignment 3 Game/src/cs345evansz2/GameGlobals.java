package cs345evansz2;

import java.util.*;

public class GameGlobals {
	
	public static Set<Action> allActions = new HashSet<Action>();
	public static Player thePlayer;
	public static java.io.PrintStream messageOut;
	public static CommandInterp interp;
	public static Set<Word> allWords = new HashSet<Word>();
	public static Set<Path> allPaths = new HashSet<Path>();
	
	
}
